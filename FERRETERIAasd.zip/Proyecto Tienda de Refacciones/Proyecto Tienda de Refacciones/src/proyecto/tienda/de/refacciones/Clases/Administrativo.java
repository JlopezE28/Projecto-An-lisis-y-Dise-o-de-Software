
package proyecto.tienda.de.refacciones.Clases;

public class Administrativo extends Empleado{
    
    public Administrativo(){ }

     Administrativo(String Usuario, String Contrasenia, float Sueldo, int DiasDescanso, String Puesto, String Observaciones, String Nombre, String ApellidoPaterno, String ApellidoMaterno, String CorreoElectronico, int Telefono) {
        super(Usuario, Contrasenia, Sueldo, DiasDescanso, Puesto, Observaciones, Nombre, ApellidoPaterno, ApellidoMaterno, CorreoElectronico, Telefono);
    }

    
    
    
     
     
     
}
